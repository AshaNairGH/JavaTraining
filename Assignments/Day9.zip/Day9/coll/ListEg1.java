package com.coll;

import java.util.*;
import static java.lang.System.*;

class City{
	private String name;
	private long pincode;
	private String state;
	
	//constructor
	public City(String name, long pincode, String state) {
		this.name = name;
		this.pincode = pincode;
		this.state = state;
	}


//Generated hashcode and equals from source to remove duplicate from HashEg
	@Override
	public int hashCode() {
		return Objects.hash(name, pincode, state);
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		City other = (City) obj;
		return Objects.equals(name, other.name) && pincode == other.pincode && Objects.equals(state, other.state);
	}



	//tostring
	@Override
	public String toString() {
		return "City [name=" + name + ", pincode=" + pincode + ", state=" + state + "]";
	}

	
//getter setter - TODO
	
}

public class ListEg {
public static void main(String[] args) {
	// create list
	//Collection <City> cities = new ArrayList<City>();
	List<City> cities = new ArrayList<City>();
	
	//add city objects to list
	cities.add(new City("City1",1234,"State1"));
	cities.add(new City("City2",2345,"State2"));
	cities.add(new City("City3",3456,"State3"));
	cities.add(new City("City1",1234,"State1"));
	
	Iterator<City> itr = cities.iterator();
	
	/*while(itr.hasNext()) {
		System.out.println(itr.next());
	}*/
	
	//enhanced for loop
	/*for(City c:cities) {
		System.out.println(c.toString());
	}*/
	
	//normal for loop
	for(int i = 0;i<=cities.size()-1;i++) {
		System.out.println(cities.get(i));
	}
}
	
}

