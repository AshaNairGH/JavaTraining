package com.coll;

import java.util.*;

//import com.Linked.City;

import static java.lang.System.*;

class City{
	private String name;
	private long pincode;
	private String state;
	
	//constructor
	public City(String name, long pincode, String state) {
		this.name = name;
		this.pincode = pincode;
		this.state = state;
	}


//Generated hashcode and equals from source to remove duplicate from HashEg
	@Override
	public int hashCode() {
		return Objects.hash(name, pincode, state);
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		City other = (City) obj;
		return Objects.equals(name, other.name) && pincode == other.pincode && Objects.equals(state, other.state);
	}



	//tostring
	@Override
	public String toString() {
		return "City [name=" + name + ", pincode=" + pincode + ", state=" + state + "]";
	}

	
//getter setter - TODO
	
}

public class ListEg {
public static void main(String[] args) {
	// create list
	//Collection <City> cities = new ArrayList<City>();
	List<City> cities = new ArrayList<City>();
	Scanner scnr = new Scanner(System.in);
	
	//add city objects to list
	
	City obj1 = new City("City1",1234,"State1");
	City obj2 =new City("City2",2345,"State2");
	City obj3 = new City("City3",3456,"State3");
	City obj4 = new City("City1",1234,"State1");
	cities.add(obj1);
	cities.add(obj2);
	cities.add(obj3);
	cities.add(obj4);
	
	display(cities, "Before adding new element");
	//adding elements in an index
	City obj5 = new City("City2a",2005,"State2a");
	cities.add(2, obj5);
	display(cities, "After adding new element");
	
	//removing object
	cities.remove(obj3);
	display(cities, "After removing an element");
	
	//enhanced for loop
	/*for(City c:cities) {
		System.out.println(c.toString());
	}*/
	
	//normal for loop
	/*for(int i = 0;i<=cities.size()-1;i++) {
		System.out.println(cities.get(i));
	}*/
	
	
}

private static void display(List<City> lcity, String msg) {
	System.out.println(msg);
Iterator<City> itr = lcity.iterator();
	
	while(itr.hasNext()) {
		System.out.println(itr.next());
	}
	System.out.println();
}
	
}

