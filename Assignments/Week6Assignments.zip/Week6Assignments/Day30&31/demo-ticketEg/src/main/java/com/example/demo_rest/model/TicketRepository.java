package com.example.demo_rest.model;

import java.util.HashMap;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo_rest.exception.InvalidPlaceNameException;
import com.example.demo_rest.exception.InvalidTicketIDException;

@RestController
@RequestMapping("/ticket")
public class TicketRepository {
	
	private HashMap<Integer, Ticket> tickets;

	public TicketRepository() {
		tickets = new HashMap<>();
		tickets.put(1, new Ticket(1,"Place1312","Place42342",111));
		tickets.put(2, new Ticket(2,"PlaceAAAA","PlaceCCCC",122));
		tickets.put(3, new Ticket(3,"PlaceDDDD","PlaceEEEE",241));
	}

	
	Ticket getTicketRepo(int ticketid) {
		Ticket ticket = tickets.get(ticketid);
		return ticket;
	}
	
	Ticket bookTicketRepo(Ticket ticket) {
		tickets.put(ticket.getId(), ticket);
		return ticket;
	}
	
	Ticket updateTicketRepo(int tid, Ticket ticket) {
		tickets.replace(tid, ticket);
		return ticket;
	}
	
	int cancelTicketRepo(int ticketid) {
		Ticket ticket = tickets.remove(ticketid);
		return ticketid;
	}	
	}
