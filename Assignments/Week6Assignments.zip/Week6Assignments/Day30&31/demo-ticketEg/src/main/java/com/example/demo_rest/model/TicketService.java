package com.example.demo_rest.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TicketService {

@Autowired
TicketRepository ticketRepo;
//Dependency Injection
	
	Ticket getTicketRepo(int ticketid) {
		return ticketRepo.getTicketRepo(ticketid);
	}
	
	Ticket bookTicketRepo(Ticket ticket) {
		return ticketRepo.bookTicketRepo(ticket);

	}
	
	Ticket updateTicketRepo(int tid, Ticket ticket) {
		return ticketRepo.updateTicketRepo(tid, ticket);

	}
	
	Ticket cancelTicketRepo(int ticketid) {
		Ticket ticket = ticketRepo.getTicketRepo(ticketid);
		ticketRepo.cancelTicketRepo(ticketid);
		return ticket;

	}	
}
