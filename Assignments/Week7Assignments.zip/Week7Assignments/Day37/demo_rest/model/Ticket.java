package com.example.demo_rest.model;

import org.springframework.stereotype.Component;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Ticket {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
private int id;
	
	
	@Column
	private String username;
	

	@Column
private String fromplace;;
	

	@Column
private String toplace;


	@Column
private float price;

public Ticket() {}

public Ticket(int id, String username, String fromplace, String toplace,  float price) {
	super();
	this.id = id;
	this.username = username;
	this.fromplace = fromplace;
	this.toplace = toplace;
	this.price = price;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public String getFromplace() {
	return fromplace;
}

public void setFromplace(String fromplace) {
	this.fromplace = fromplace;
}

public String getToplace() {
	return toplace;
}

public void setToplace(String toplace) {
	this.toplace = toplace;
}

public float getPrice() {
	return price;
}

public void setPrice(float price) {
	this.price = price;
}

}