package cmap;

class PChars extends Thread {

	@Override
	public void run() {
		try {

			for (int i = MultithreadCommonStringEg.getIndex() ; i < MultithreadCommonStringEg.getString1().length(); i++) {
				System.out.print(MultithreadCommonStringEg.getString1().charAt(i)+" ");
				MultithreadCommonStringEg.incrIndex();

				Thread.sleep(30);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

public class MultithreadCommonStringEg {
	private static String string1 = "This is to print individual characters";
	private static int index = 0;
	

	public static String getString1() {
		return string1;
	}

	public static void setString1(String string1) {
		MultithreadCommonStringEg.string1 = string1;
	}

	public static int getIndex() {
		return index;
	}

	public static int incrIndex() {
		return index++;
	}

	public static void setIndex(int index) {
		MultithreadCommonStringEg.index = index;
	}

	public static void main(String[] args) {

		try {

			PChars thread = new PChars();
			thread.start();
			for (int i = 0; i < string1.length(); i++) {
				System.out.print(string1.charAt(i)+" ");
				Thread.sleep(25);
			}

		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

}

