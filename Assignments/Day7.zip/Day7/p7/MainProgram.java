package com.p7;

import com.p5.PermanentEmployee;
import com.p6.TemporaryEmployee;

public class MainProgram {
	public static void main(String [] args) {
		PermanentEmployee pobj = new PermanentEmployee(111, "Name111",145.6f,"addr1");
    pobj.displayp();
    
    TemporaryEmployee tobj = new TemporaryEmployee(222, "Name222", 550, "Company Address1");
    tobj.display();
}
}
