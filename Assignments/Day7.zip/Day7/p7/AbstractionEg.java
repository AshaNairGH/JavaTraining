package com.p7;

abstract class Animal{
	String name;
	
	
	public Animal(String name) {
		super();
		this.name = name;
	}

	abstract void move();
	
	void eat() {
		System.out.println("Animal eat");
	}
	
}


class Snake extends Animal{

	public Snake(String name) {
		super(name);
	}

	@Override
	void move() {
		System.out.println("Crawling .....");
		
	}
	
	
}
public class AbstractionEg {
	public static void main(String[] args) {
		Animal obj1 = new Snake("Viper");
		Animal obj2 = new Snake("Python");
		obj1.move();
		System.out.println("Snake:" + obj1.name);
		System.out.println("Snake:" + obj2.name);
	}

}
