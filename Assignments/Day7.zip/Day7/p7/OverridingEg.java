package com.p7;

class Product{
	int id;
	String name;
	
	
	public Product(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	void display() {
		System.out.println("Product display");
	}
	
	public String toString() {
		return "id:"+id+" name:"+name;
	}
	
	public boolean equals(Object obj) {
		Product o = (Product)obj;
		if (this.id==o.id) 
		return true;
		else
		return false;		
	
	}
}

class ElectronicProduct extends Product{
	float voltage;
	public ElectronicProduct(int id, String name,float voltage) {
		super(id, name);
		this.voltage = voltage;
	}
	
	void display() {
		System.out.println("ElectronicProduct display");
	}
}

public class OverridingEg {
public static void main(String[] args) {
	//Product obj = new ElectronicProduct();
			//obj.display();//display of derived will be called
			Product obj1 = new Product(12,"Chair1");
			obj1.display();//display of base will be called
			System.out.println("Product1 obj is: "+obj1.toString());
			
			Product obj2 = new Product(12,"Chair2");
			System.out.println("Product2 obj is: "+obj2.toString());
			System.out.println(obj2.equals(obj1));						
}
}
