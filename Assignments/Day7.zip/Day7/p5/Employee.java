package com.p5;

public class Employee {

	private int eid;
	private String name;
	//final int x = 20;
	
	protected Employee(){
		System.out.println("Employee");
	}
	
	protected Employee(int eid, String name) {
		this.eid = eid;
		this.name = name;
	}

	public int getEid() {
		//final Employee obj = new Employee();
		return eid;
	}

	public void setEid(int eid) {
		//final int x = 20;
		this.eid = eid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void displaye(){
		System.out.println("Employee id: "+eid+" Name: "+name);
	}
	
}
	
