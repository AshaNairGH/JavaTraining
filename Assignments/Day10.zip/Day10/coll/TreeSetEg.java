package com.coll;

import java.util.*;

class Country{
	private String name;
	private double gdp;
	public Country(String name, double gdp) {
		super();
		this.name = name;
		this.gdp = gdp;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getGdp() {
		return gdp;
	}
	public void setGdp(double gdp) {
		this.gdp = gdp;
	}
	@Override
	public String toString() {
		return "Country [name=" + name + ", gdp=" + gdp + "]";
	}	
}

public class TreeSetEg {
public static void main(String[] args) {
	/*TreeSet <String> tss= new TreeSet<>(new MyComparator());
			
	tss.add("sds sd asdasd");
	tss.add("yuiyuiyui");
	tss.add("mbnmbmb v");
	tss.add("ooioiuoui");
	
	Iterator<String> itrs = tss.iterator();
	for(;itrs.hasNext();){
		System.out.println(itrs.next()); 

	}*/
	
	TreeSet <Country> tss= new TreeSet<>(new MyComparator());
	
	tss.add(new Country("India", 45));
	tss.add(new Country("Japan", 89));
	tss.add(new Country("Australia", 30));
	tss.add(new Country("England", 48));
	
	Iterator<Country> itrs = tss.iterator();
	for(;itrs.hasNext();){
		System.out.println(itrs.next()); 

	}
}
}

class MyComparator implements Comparator<Country>{

	@Override
	public int compare(Country c1, Country c2) {
		
		//return str1.compareTo(str2); //ascending order
		//return str2.compareTo(str1 ); //ascending order
		return c2.toString().compareTo(c1.toString()); //descending order
	}
	
}

