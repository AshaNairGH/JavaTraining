package com.p7;

class Vehicles{
	String name;
	
	static void met(){
		System.out.println("A met");
	}
}

class bus extends Vehicles{
	static void met() {
		
	}
}

class car extends Vehicles{
	
}


public class Vehicle {
public static void main(String[] args) {
	Vehicles[] arr = new Vehicles[5];
	arr[0]=new bus();
	arr[1]=new car();
	bus.met();
	//bus o = new bus();
	//o.met();
	
}
}
