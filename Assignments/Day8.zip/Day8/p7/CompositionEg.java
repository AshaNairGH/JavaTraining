package com.p7;

import java.util.Arrays;

class Department{
	private int id;
	private String deptname;
	String hodname;
	
	public Department(int id, String deptname, String hodname) {
		this.id = id;
		this.deptname = deptname;
		this.hodname = hodname;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	public String getHodname() {
		return hodname;
	}

	public void setHodname(String hodname) {
		this.hodname = hodname;
	}

	@Override
	public String toString() {
		return "Department [id=" + id + ", deptname=" + deptname + ", hodname=" + hodname + "]";
	}
	
	
			
}

class University{
	private String name;
	private String addr;
	Department depts[];
	
	public University(String name, String addr, Department[] depts) {
		super();
		this.name = name;
		this.addr = addr;
		this.depts = depts;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public Department[] getDepts() {
		return depts;
	}
	public void setDepts(Department[] depts) {
		this.depts = depts;
	}

	@Override
	public String toString() {
		return "University [name=" + name + ", addr=" + addr + ", depts=" + Arrays.toString(depts) + "]";
	}
	
	
}
public class CompositionEg {
public static void main(String[] args) {
	//Create atleast 2 dept and set those dept to university obj and dispaly univ obj
	Department dobj1 = new Department(1, "Physics", "Dr.Manish");
	Department dobj2 = new Department(2, "Chemistry", "Dr.Retheesh");
	Department[] aobj = new Department[2];
	aobj[0] = dobj1;
	aobj[1] = dobj2;
		
	University obj = new University("Kerala University", "Address", aobj);
	System.out.println("University details:" + obj.toString());
}
}
