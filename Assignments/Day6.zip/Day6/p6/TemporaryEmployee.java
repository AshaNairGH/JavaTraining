package com.p6;

import com.p5.Employee;

public class TemporaryEmployee extends Employee{

	float hourlypay;
	String company_addr;
	
	
	public TemporaryEmployee(float hourlypay, String company_addr) {
		super();
		this.hourlypay = hourlypay;
		this.company_addr = company_addr;
	}

public void display() {
	displaye();
	System.out.println("Hourlypay is:"+ hourlypay+ " Company address is: "+ company_addr);
}

}
