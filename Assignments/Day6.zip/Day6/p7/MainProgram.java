package com.p7;

import com.p5.permanantEmployee;
import com.p6.TemporaryEmployee;

public class MainProgram {
	public static void main(String [] args) {
	permanantEmployee pobj = new permanantEmployee(145.6f,"addr1");
    pobj.displayp();
    
    TemporaryEmployee tobj = new TemporaryEmployee(550, "Company Address1");
    tobj.display();
}
}
