package com.service;

import java.util.HashMap;
import java.util.Map;

import com.app.Product;

public class ShoppingCart {
private Map<Product, Integer> items = new HashMap<>();

//Add products to cart

public void addProduct(Product product, int quantity) {
	if (items.containsKey(product)) {
		int q = items.get(product);
		items.put(product, q+quantity);}
	else {
		items.put(product, quantity);
	}
}
 
//View products in the cart
public void viewProduct() {
	for(Map.Entry<Product,Integer> entry : items.entrySet()) {
		System.out.println(entry.getKey() +" -> Quantity: "+entry.getValue());
	}
}

//Removing products in the cart
public void removeItem(String product_name) {
	items.remove(product_name);
	}

//Checkout
public double totalAmount() {
	double total=0.0;
	for(Map.Entry<Product,Integer> entry:items.entrySet()) {
		Product product = entry.getKey();
		int quantity=entry.getValue();
		total += product.getPrice()*quantity;
	}
	return total;
}
}
