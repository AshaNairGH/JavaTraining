package com.data;

import java.util.*;
import java.util.stream.Stream;

import com.app.Product;

public class Inventory {
private List<Product> lproducts;

public Inventory() {
	lproducts = new ArrayList<>();
	
	lproducts.add(new Product(1,"Oppo Mobile","6GB RAM","Electronics",18550.00));
	lproducts.add(new Product(2,"Samsung TV","43 inch","Electronics",42990.00));
	lproducts.add(new Product(3,"Recliner","Single seater","Furniture",15999.00));
	lproducts.add(new Product(4,"Toy Truck","Plastic","Toys",565.00));
	lproducts.add(new Product(5,"Coffee Table","Round wooden","Furniture",9999.00));
	lproducts.add(new Product(6,"Flash Cards","Educational","Toys",398.00));
	lproducts.add(new Product(7,"Shoes","Sports wear","Footwear",1120.00));
	lproducts.add(new Product(8,"Redmi Mobile","4GB RAM","Electronics",15500.00));
	lproducts.add(new Product(9,"Shoes","Formal wear","Footwear",1599.00));
	lproducts.add(new Product(10,"Shoes","Casual wear","Footwear",890.00));
}

//search products
public List<Product> searchProducts(String product_partialname){
	return lproducts.stream().filter(item->item.getProduct_name().toLowerCase().contains(product_partialname.toLowerCase())).toList();
}
}
