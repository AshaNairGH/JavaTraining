package com.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.app.Product;
import com.service.ShoppingCart;

public class EcomData {
private Inventory inv;
private ShoppingCart sc;

public static void main(String[] args) {
	Scanner scnr = new Scanner(System.in);
	Inventory inv = new Inventory();
	ShoppingCart sc = new ShoppingCart();
	Product pr = new Product(0, "", "", "", 0.0);
	int choice;
	
	do {	
	System.out.println("*******Shopping Cart*******");
	System.out.println("1. Search Products");
	System.out.println("2. Add Products");
	System.out.println("3. View Cart");
	System.out.println("4. Checkout Cart");
	System.out.println("5. Exit");
	System.out.println("Enter your choice: ");
	
	choice = scnr.nextInt();
	
	switch(choice) {
	case 1: 
		System.out.println("---Search Product---");
		System.out.println("Enter product: ");
		String item = scnr.next();
		System.out.println(inv.searchProducts(item));
		break;
	case 2: 
		System.out.println("---Add Product---");
		System.out.println("Enter product: ");
		pr.setProduct_name(scnr.next());
		System.out.println("Enter quantity: ");
		int qn = scnr.nextInt();		
		sc.addProduct(pr,qn);
		break;
	case 3: 
		System.out.println("---View Product---");
		sc.viewProduct();
		break;
	case 4: 
		System.out.println("---Total Amount---");
		System.out.println("Total Amount in cart: "+sc.totalAmount());
		break;
	case 5: 
		System.out.println("Exit!!!");
		break;
		default:
			System.out.println("Invalid choice!");
	}	
		
	}while(choice!=5);
}
}
