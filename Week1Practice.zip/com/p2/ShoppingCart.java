package com.p2;

import com.p1.Product;

public class ShoppingCart {
	//data members
		//Array of products
		Product aprod[];
		int cindex;
		
	//Constructor
		public ShoppingCart(){
			aprod = new Product[5];
			cindex = 0;
		}
		
	//Member methods
		//add product to cart
		public Product addProduct(Product prod) {
			aprod[cindex]=prod;
			cindex++;
			System.out.println("Added product with id: "+prod.getId());
			return prod;
		}
		//List products in the cart
		public void listProducts() {
			for(int i = 0;i<cindex;i++) {			
				aprod[i].display();
			}
		}
		
		//empty shopping cart
		public void emptyCart() {
				aprod = new Product[5];
				cindex = 0;
				System.out.println("Deleted all products from shopping cart");
			}
			//checkout
			//calculate the total amount and print and make cart empty
			void checkout() {
				
			}	
}
