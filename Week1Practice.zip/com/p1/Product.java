package com.p1;

public class Product {
	//data members
		private int id;
		private String name;
		private static int num_of_prods=100;
		final static int MAX_PRODUCTS = 250;
		
		//constructor
		
		private Product(){
			id = 0;
			name="";
			System.out.println("Trying this");
			//num_of_prods=100;
		}
		
		public Product(int pid, String pname){
			this();
			id=pid;
			name=pname;	
		}
		
		
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			final float PI = 3.14f;
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		
		public static int getNum_of_prods() {
			return num_of_prods;
		}
		public static void setNum_of_prods(int num_of_prods) {
			Product.num_of_prods = num_of_prods;
		}
		
		
		//member method
		public static int get_num_prods() {
			//display();
			return num_of_prods;
		}
		
		public void display() {			
			System.out.println("Id="+id+" Name=" +name+" Total products="+get_num_prods());
		}
		
		
}
