package Programs;

class ShoppingCart{
	
	//data members
	//Array of products
	Product aprod[];
	int cindex;
	
	//Constructor
	ShoppingCart(){
		aprod = new Product[5];
		cindex = 0;
	}
	
	//Member methods
	//add product to cart
	Product addProduct(Product prod) {
		aprod[cindex]=prod;
		cindex++;
		return prod;
	}
	//List products in the cart
	void listProduct() {
		for(int i = 0;i<cindex;i++) {
			aprod[i].display();
		}
	}
	//empty shopping cart
	void emptyCart() {
		aprod = new Product[5];
		cindex = 0;
		System.out.println("Deleted all products from shopping cart");
	}
	//checkout
	//calculate the total amount and print and make cart empty
}

class Product{
	int id;
	String name;
	//float price;
	
	Product(){
		id=0;
		name="";
	}
	
	Product(int pid, String pname){
		id=pid;
		name=pname;		
	}
	
	void display() {
		System.out.println("id="+id+" name=" +name);
	}
}

public class ObjectOriented {
public static void main(String[] args) {
	Product pobj = new Product(301, "Furniture - Sofa set");
	/*pobj.id = 1;
	pobj.name = "Laptop";
	pobj.price = (float)59800.50;*/
	pobj.display();
	
	//array of objects
	Product apobj[] = new Product[3];
	apobj[0] = new Product(100,"Mobile");
	apobj[1]= new Product(200, "Clothing");
	apobj[2]= new Product(300, "Furniture");
	
	//enhanced for loop
	for(Product prod: apobj) {
		prod.display();
	}
	
	//normal for loop
/*	for(int i = 0; i<=apobj.length-1;i++)
	{
		apobj[i].display();
	}*/
}
}


/*Obj oriented recap - Class, Object(as parameter,return,locally in method), datamember, member method,constructor,static, getter&setter, this,
 * Memory segments(stack,heap,data segment(static members are allocated memory here),code),Access specifiers, Method chaining,Final
 */