package Programs;
import java.util.Scanner;

public class UsingArray {
public static void main(String[] args) {
	int pincome[] = new int[5];
	pincome[0] =32;
	pincome[1] =21;
	pincome[2] =11;
	pincome[3] =41;
	pincome[4] =15;
	
	//Scanner scnr = new Scanner(System.in);
	
	System.out.println("................");
	for(int i=pincome.length-1;i>=0;i--) {
		System.out.println("PerCapital Income of City" +i+ " is" +pincome[i]);
	}
	
	System.out.println("................");
	int min_pincome = minincome(pincome);
	System.out.println("Min PerCapital Income of City" +min_pincome);
	
System.out.println("................");
int max_pincome = maxincome(pincome);
System.out.println("Max PerCapital Income of City" +max_pincome);

System.out.println("................");
int[] rev_pincome = reverse(pincome);
System.out.println("Reversed Array: ");
//System.out.println(rev_pincome);
print(rev_pincome);

System.out.println("Array before sorting...");
print(pincome);

int[] rpincome = sort(pincome);

System.out.println("Array after sorting......");
print(rpincome);
}

static void print(int[] arr){
	System.out.println("......BEGIN..........");
	for(int i = 0;i<arr.length;i++) {
		System.out.println("PerCapital Income of City" +i+ " is" +arr[i]);
	}
	System.out.println("......END..........");
}

static int minincome(int[] avalues) {
	int min_pincome = avalues[0];
	for(int i = 1;i<avalues.length;i++) {
		if(min_pincome>avalues[i]) {
			min_pincome=avalues[i];
		}
	}
	return min_pincome;
}

static int maxincome(int[] avalues) {
	int max_pincome = avalues[0];
	for(int i = 1;i<avalues.length;i++) {
		if(max_pincome<avalues[i]) {
			max_pincome=avalues[i];
		}
	}
	return max_pincome;
}

static int[] reverse(int[] avalues) {
	int n = avalues.length, tmp;
	for(int i = 0;i<n/2;i++) {
		tmp = avalues[i];
		avalues[i]=avalues[n-i-1];
		avalues[n-i-1] = tmp;
	}
return avalues;

}


static int[] sort(int[] avalues) {

    for (int i = 0; i < avalues.length; i++) {
        for (int j = 0; j < avalues.length - 1 - i; j++) {
            if (avalues[j] > avalues[j + 1]) {
                int tmp = avalues[j];
                avalues[j] = avalues[j + 1];
                avalues[j + 1] = tmp;
            }
        }
    }

    return avalues;
}
}

