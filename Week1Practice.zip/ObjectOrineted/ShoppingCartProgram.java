package ObjectOrineted;

import com.p1.Product;
import com.p2.ShoppingCart;

/*class Product{
	//data members
	int id;
	String name;
	static int num_of_prods=100;
	
	//constructor
	
	Product(){
		id = 0;
		name="";
		//num_of_prods=100;
	}
	Product(int pid, String pname){
		id=pid;
		name=pname;	
	}
	
	//member method
	
	static int get_num_prods() {
		//display();
		return num_of_prods;
	}
	
	void display() {
		get_num_prods();
		System.out.println("id="+id+" name=" +name);
	}
	
	
}

class ShoppingCart{
	
//data members
	//Array of products
	Product aprod[];
	int cindex;
	
//Constructor
	ShoppingCart(){
		aprod = new Product[5];
		cindex = 0;
	}
	
//Member methods
	//add product to cart
	Product addProduct(Product prod) {
		aprod[cindex]=prod;
		cindex++;
		System.out.println("Added product with id: "+prod.id);
		return prod;
	}
	//List products in the cart
	void listProducts() {
		for(int i = 0;i<cindex;i++) {			
			aprod[i].display();
		}
	}
	
	//empty shopping cart
		void emptyCart() {
			aprod = new Product[5];
			cindex = 0;
			System.out.println("Deleted all products from shopping cart");
		}
		//checkout
		//calculate the total amount and print and make cart empty
		void checkout() {
			
		}		
}*/
	
public class ShoppingCartProgram {
	public static void main(String[] args) {
		ShoppingCart scart = new ShoppingCart();
		
		System.out.println("Total number of products: " +Product.get_num_prods());
		
		Product p1 = new Product(100, "Mobile");
		scart.addProduct(p1);
		
		Product p2 = new Product(200, "Clothing");
		scart.addProduct(p2);
		
		scart.listProducts();
		
		scart.emptyCart();
	}
}
