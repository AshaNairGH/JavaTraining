package com.data;

import java.util.*;
import java.util.stream.Stream;

import com.app.Product;

public class Inventory {
private List<Product> lproducts;

public Inventory(List<Product> lproducts) {
	this.lproducts = lproducts;
}


public List<Product> getLproducts() {
	return lproducts;
}

public void setLproducts(List<Product> lproducts) {
	this.lproducts = lproducts;
}

@Override
public String toString() {
	return "Inventory [lproducts=" + lproducts + "]";
}


public Inventory() {
	lproducts = new ArrayList<>();
	
	lproducts.add(new Product(1,"Oppo Mobile","6GB RAM","Electronics",18550.00));
	lproducts.add(new Product(2,"Samsung TV","43 inch","Electronics",42990.00));
	lproducts.add(new Product(3,"Recliner","Single seater","Furniture",15999.00));
	lproducts.add(new Product(4,"Toy Truck","Plastic","Toys",565.00));
	lproducts.add(new Product(5,"Coffee Table","Round wooden","Furniture",9999.00));
	lproducts.add(new Product(6,"Flash Cards","Educational","Toys",398.00));
	lproducts.add(new Product(7,"Shoes","Sports wear","Footwear",1120.00));
	lproducts.add(new Product(8,"Redmi Mobile","4GB RAM","Electronics",15500.00));
	lproducts.add(new Product(9,"Shoes","Formal wear","Footwear",1599.00));
	lproducts.add(new Product(10,"Shoes","Casual wear","Footwear",890.00));
	
}

//Search products with name
public List<Product> searchProducts(String productpartialname){
	return lproducts.stream().filter(e->e.getProduct_name().toLowerCase().contains(productpartialname.toLowerCase())).toList();
}

//Search products with product id
public List<Product> searchProductids(int productid){
	return lproducts.stream().filter(e->e.getProduct_id()==(productid)).toList();
}

//List available products
public void displayItems(){	
	lproducts.forEach((item)->{ System.out.println(item); });
}
}
